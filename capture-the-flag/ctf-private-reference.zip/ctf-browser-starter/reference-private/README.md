# Private reference material — not game assets

This directory holds the uploaded legacy map and selected extracted script/object
files for local analysis. It is intentionally ignored by Git. Do not publish it,
copy it into browser assets, or deploy it. The core-rule specification in ../docs
is the portable design record. The original map remains unchanged.

The extraction manifest records hashes. The JASS index and object JSON are generated
by tools/audit_reference.py. They may contain old usernames, inappropriate strings,
and references to third-party assets; do not carry that material into the new UI.
